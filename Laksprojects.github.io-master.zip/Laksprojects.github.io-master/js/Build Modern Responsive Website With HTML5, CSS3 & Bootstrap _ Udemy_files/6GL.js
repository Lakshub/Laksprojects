// Qualaroo for udemy.com
// (C) 2019 Qualaroo. All rights reserved.
// qualaroo.com

//$ site: 27311, generated: 2019-11-19 22:23:28 UTC
//$ client: 2.0.55

!function(){var e=document,t=e.getElementsByTagName("script")[0],r=e.createElement("script");r.type="text/javascript",r.async=!0,r.src="https://cl.qualaroo.com/ki.js/34436/6GLqoo.js",t.parentNode.insertBefore(r,t)}();