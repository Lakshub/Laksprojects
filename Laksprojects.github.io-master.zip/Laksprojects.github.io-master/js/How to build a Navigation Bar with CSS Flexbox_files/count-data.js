var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"Leave a comment","multiple":"View Comments ({num})","one":"View Comments ({num})"}},"counts":[{"id":"https:\/\/freshman.tech\/flexbox-navbar\/","comments":3}]});
}